<script src="<?= base_url('assets/js/app.js') ?>"></script>
</body>

</html>